// Decompiled by DJ v3.5.5.77 Copyright 2003 Atanas Neshkov  Date: 9/18/2008 6:11:15 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   JDBCInfo.java

package dbcon;


public class JDBCInfo
{

    public JDBCInfo()
    {
    }

    public static String DRIVER = "sun.jdbc.odbc.JdbcOdbcDriver";
    public static String URL = "jdbc:odbc:fsm";
    public static String USER = "fsm";
    public static String PASS = "fsm";

}